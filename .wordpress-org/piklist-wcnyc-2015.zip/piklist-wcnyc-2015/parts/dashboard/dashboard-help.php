<?php
/*
Title: Need Help?
*/
?>

<p>
  Your new website is full of awesome new features. We have included lots of inline help and descriptions to explain how to use it. If you ever need help, please email us at <a href="mailto:help@helpme.com" target="_blank">help@helpme.com</a>
</p>