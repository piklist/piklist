<?php
/*
Title: A Featured Image is Required.
Anchor ID: #postimagediv
Edge: bottom
Align: top
*/
?>

<p>
  You can not publish a post without adding a Featured Image.
</p>