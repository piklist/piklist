<?php
/*
Title: Switch Post Type
Post Type: post,page
Priority: high
Context: side
*/

  piklist('field', array(
    'type' => 'select'
    ,'scope' => 'post'
    ,'field' => 'post_type'
    ,'label' => 'Available Post Types'
    ,'value' => get_post_type()
    ,'description' => 'Posts and Pages are handled differently. Feel free to change'
    ,'choices' => array(
      'post' => 'Post'
      ,'page' => 'Page'
    )
  ));