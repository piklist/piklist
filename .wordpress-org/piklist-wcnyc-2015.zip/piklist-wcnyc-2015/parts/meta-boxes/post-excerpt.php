<?php
/*
Title: Excerpt
Post Type: post
Context: normal
Priority: core
Order: 1
Extend: postexcerpt
Extend Method: replace
*/

  piklist('field', array(
    'type' => 'editor'
    ,'scope' => 'post'
    ,'field' => 'post_excerpt'
    ,'description' => 'Excerpts are optional hand-crafted summaries of your content that can be used in your theme. <a href="https://codex.wordpress.org/Excerpt" target="_blank">Learn more about manual excerpts</a>'
    ,'template' => 'field_description'
  ));