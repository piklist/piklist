<?php
/*
Title: Featured Image
Post Type: post
Priority: default
Context: side
Extend: postimagediv
Extend Method: replace
*/
  
  piklist('field', array(
    'type' => 'file'
    ,'field' => '_thumbnail_id'
    ,'options' => array(
      'title' => 'Set featured image'
      ,'button' => 'Set featured image'
    )
    ,'required' => true
    ,'validate' => array(
      array(
        'type' => 'limit'
        ,'options' => array(
          'min' => 1
          ,'max' => 1
        )
      )
    )
  ));