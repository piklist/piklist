<?php
/*
Extend: formatdiv
Extend Method: before
Title: Choose a Format
Post Type: post
Priority: default
Context: side
*/
?>

<p>
  Each format has a stylistic difference for your post. Pick a format, add content to your post the way you normally would, and publish!
</p>

<p>
  <a href="https://en.support.wordpress.com/posts/post-formats/" class="button button-secondary" target="_blank"><?php _e('Learn more'); ?> &raquo;</a>
</p>