<?php
/*
Plugin Name: WordCamp NYC
Plugin URI: http://piklist.com
Description: Presentation for WordCamp NYC
Version: 2015
Author: Piklist
Author URI: http://piklist.com/
Plugin Type: Piklist
*/